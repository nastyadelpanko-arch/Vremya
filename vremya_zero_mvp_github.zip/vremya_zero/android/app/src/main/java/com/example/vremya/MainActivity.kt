package com.example.vremya

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.View
import android.widget.*
import java.time.*
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.max

private data class Task(
    val title: String,
    val minutes: Int = 30,
    val date: LocalDate = LocalDate.now(),
    val fixedStart: LocalTime? = null,
    val priority: Int = 2,
    var plannedStart: LocalTime? = null,
    var done: Boolean = false
)

class MainActivity : Activity() {
    private lateinit var timeline: LinearLayout
    private val prefs by lazy { getSharedPreferences("vremya", MODE_PRIVATE) }
    private val tasks = mutableListOf<Task>()
    private var viewMode = "today"
    private val timeFmt = DateTimeFormatter.ofPattern("HH:mm")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        timeline = findViewById(R.id.timeline)
        load()
        plan()
        render()
        findViewById<Button>(R.id.addButton).setOnClickListener { addTaskDialog() }
        findViewById<Button>(R.id.voiceButton).setOnClickListener { voiceInput() }
        findViewById<Button>(R.id.todayTab).setOnClickListener { viewMode="today"; render() }
        findViewById<Button>(R.id.weekTab).setOnClickListener { viewMode="week"; render() }
        findViewById<Button>(R.id.monthTab).setOnClickListener { viewMode="month"; render() }
    }

    private fun addTaskDialog() {
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(40,0,40,0) }
        val title = EditText(this).apply { hint="Что нужно сделать?"; textSize=18f }
        val duration = EditText(this).apply { hint="Длительность, минут (например 45)"; inputType=2; textSize=18f }
        val fixed = EditText(this).apply { hint="Фиксированное время, например 15:00 (необязательно)"; textSize=18f }
        box.addView(title); box.addView(duration); box.addView(fixed)
        AlertDialog.Builder(this).setTitle("Новое дело").setView(box)
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Добавить") { _, _ ->
                val d = duration.text.toString().toIntOrNull()?.coerceIn(5, 480) ?: 30
                val fs = fixed.text.toString().trim().let { runCatching { if(it.isBlank()) null else LocalTime.parse(it) }.getOrNull() }
                if(title.text.isNotBlank()) { tasks.add(Task(title.text.toString().trim(), d, LocalDate.now(), fs)); save(); plan(); render() }
            }.show()
    }

    private fun voiceInput() {
        if(android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7); return
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Например: завтра в 15 врач, ещё купить продукты на час")
        }
        try { startActivityForResult(i, 42) } catch (_: Exception) { Toast.makeText(this,"Голосовой ввод недоступен на этом телефоне",Toast.LENGTH_LONG).show() }
    }

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==42 && resultCode==RESULT_OK) {
            val text=data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: return
            parseVoice(text)
        }
    }

    private fun parseVoice(text:String) {
        val lower=text.lowercase(Locale("ru"))
        val fixed=Regex("(?:в|на)\\s+(\\d{1,2})(?::(\\d{2}))?").find(lower)
        val hour=fixed?.groupValues?.get(1)?.toIntOrNull()
        val minute=fixed?.groupValues?.get(2)?.ifBlank{"0"}?.toIntOrNull() ?: 0
        val mins=when {
            lower.contains("полтора часа") -> 90
            lower.contains("часа два") -> 120
            lower.contains("два часа") -> 120
            lower.contains("полчаса") -> 30
            lower.contains("час") -> 60
            else -> 30
        }
        val date=when {
            lower.contains("послезавтра") -> LocalDate.now().plusDays(2)
            lower.contains("завтра") -> LocalDate.now().plusDays(1)
            else -> LocalDate.now()
        }
        val cleaned=text.replace(Regex("(?i)завтра|послезавтра"),"").trim().ifBlank { text }
        val title=cleaned.replace(Regex("(?i)в\\s+\\d{1,2}(?::\\d{2})?"),"").trim().trim(',', '.')
        val start=hour?.let { if(it in 0..23 && minute in 0..59) LocalTime.of(it,minute) else null }
        AlertDialog.Builder(this).setTitle("Проверим план")
            .setMessage("Я понял:\n\n$title\nДата: ${date.format(DateTimeFormatter.ofPattern("dd.MM"))}\nДлительность: $mins мин${if(start!=null) "\nВремя: ${start.format(timeFmt)}" else "\nВремя: предложу сам"}")
            .setNegativeButton("Изменить",null)
            .setPositiveButton("Добавить") { _, _ -> tasks.add(Task(title,mins,date,start)); save(); plan(); render() }.show()
    }

    private fun plan() {
        val today=LocalDate.now()
        val dayTasks=tasks.filter { it.date==today }
        val fixed=dayTasks.filter { it.fixedStart!=null }.sortedBy { it.fixedStart }
        val flexible=dayTasks.filter { it.fixedStart==null && !it.done }.sortedWith(compareByDescending<Task>{it.priority}.thenBy{it.minutes})
        fixed.forEach { it.plannedStart=it.fixedStart }
        var cursor=LocalTime.of(9,0)
        flexible.forEach { t ->
            var candidate=cursor
            var placed=false
            repeat(30) {
                val end=candidate.plusMinutes(t.minutes.toLong())
                val clash=fixed.any { f -> val s=f.fixedStart!!; val e=s.plusMinutes(f.minutes.toLong()); candidate.isBefore(e) && end.isAfter(s) }
                if(!clash && end<=LocalTime.of(20,0)) { t.plannedStart=candidate; cursor=end.plusMinutes(10); placed=true; return@repeat }
                candidate=candidate.plusMinutes(15)
            }
            if(!placed) t.plannedStart=null
        }
        save()
    }

    private fun render() {
        timeline.removeAllViews()
        val today=LocalDate.now()
        val visible=when(viewMode){
            "week" -> tasks.filter{!it.done && !it.date.isBefore(today) && it.date.isBefore(today.plusDays(7))}.sortedWith(compareBy<Task>{it.date}.thenBy{it.plannedStart ?: LocalTime.MAX})
            "month" -> tasks.filter{!it.done && !it.date.isBefore(today) && it.date.isBefore(today.plusMonths(1))}.sortedWith(compareBy<Task>{it.date}.thenBy{it.plannedStart ?: LocalTime.MAX})
            else -> tasks.filter{it.date==today && !it.done}.sortedBy{it.plannedStart ?: LocalTime.MAX}
        }
        if(visible.isEmpty()) {
            val empty=TextView(this).apply{text="На этот период пока ничего не запланировано.\n\nДобавьте дело — я попробую найти для него место."; textSize=18f; setTextColor(0xFF686B78.toInt()); setPadding(12,40,12,40)}
            timeline.addView(empty); return
        }
        var lastDate:LocalDate?=null
        visible.forEach { t ->
            if(viewMode!="today" && t.date!=lastDate){
                val h=TextView(this).apply{text=when(t.date){today->"Сегодня";today.plusDays(1)->"Завтра";else->t.date.format(DateTimeFormatter.ofPattern("EEEE, dd.MM",Locale("ru")))}; textSize=20f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(0xFF171923.toInt()); setPadding(4,20,4,8)}
                timeline.addView(h); lastDate=t.date
            }
            val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,18,20,18);setBackgroundColor(0xFFFFFFFF.toInt())}
            val time=TextView(this).apply{text=(t.plannedStart?.format(timeFmt) ?: "—") + "   " + t.minutes + " мин"; textSize=15f; setTextColor(0xFF5960A8.toInt())}
            val name=TextView(this).apply{text=t.title; textSize=19f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(0xFF171923.toInt()); setPadding(0,6,0,0)}
            row.addView(time); row.addView(name)
            row.setOnClickListener { t.done=true; save(); plan(); render(); Toast.makeText(this,"Готово",Toast.LENGTH_SHORT).show() }
            val lp=LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,10); timeline.addView(row,lp)
        }
        val unscheduled=visible.filter{it.plannedStart==null}
        if(unscheduled.isNotEmpty()) {
            val warning=TextView(this).apply{text="⚠ Не всё помещается в доступное время. Нажмите на дело, чтобы отметить выполненным, или измените длительность."; textSize=16f; setTextColor(0xFF8A4B00.toInt()); setPadding(10,18,10,18)}
            timeline.addView(warning)
        }
    }

    private fun save() {
        val raw=tasks.joinToString("\\n") { listOf(it.date.toString(),it.title.replace("|","/"),it.minutes,it.fixedStart?.toString() ?: "",it.done).joinToString("|") }
        prefs.edit().putString("tasks",raw).apply()
    }

    private fun load() {
        val raw=prefs.getString("tasks","") ?: ""
        if(raw.isBlank()) return
        raw.lines().forEach { line ->
            val p=line.split("|",limit=5); if(p.size<5) return@forEach
            val d=runCatching{LocalDate.parse(p[0])}.getOrNull() ?: return@forEach
            val fixed=runCatching{if(p[3].isBlank()) null else LocalTime.parse(p[3])}.getOrNull()
            tasks.add(Task(p[1],p[2].toIntOrNull()?:30,d,fixed,2,null,p[4].toBoolean()))
        }
    }
}
