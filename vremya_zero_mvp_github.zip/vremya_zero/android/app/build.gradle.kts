plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.vremya"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.vremya"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.2"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
}
